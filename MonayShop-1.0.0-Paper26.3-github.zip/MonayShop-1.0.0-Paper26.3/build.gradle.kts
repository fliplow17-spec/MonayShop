plugins {
    java
}

group = "lol.playsmp"
version = "1.0.0"

description = "A modern, configurable survival shop GUI for Paper 26.3."

repositories {
    maven {
        name = "papermc"
        url = uri("https://repo.papermc.io/repository/maven-public/")
    }
    mavenCentral()
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:26.3.build.+")
    compileOnly("com.github.MilkBowl:VaultAPI:1.7.1")
}

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(25))
}

tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
    options.release.set(25)
}

tasks.processResources {
    val pluginVersion = project.version.toString()
    inputs.property("version", pluginVersion)
    filesMatching("plugin.yml") {
        expand("version" to pluginVersion)
    }
}

tasks.jar {
    archiveBaseName.set("MonayShop")
    archiveVersion.set(project.version.toString())
    manifest {
        attributes(
            "Implementation-Title" to "MonayShop",
            "Implementation-Version" to project.version,
            "Built-For" to "Paper 26.3"
        )
    }
}
