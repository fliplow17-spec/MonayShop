package lol.playsmp.monayshop;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public final class MonayShop extends JavaPlugin {
    private ShopManager shopManager;
    private Economy economy;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        saveResource("shops.yml", false);

        if (!setupEconomy()) {
            getLogger().severe("Vault economy provider not found. Install Vault and an economy plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        shopManager = new ShopManager(this);
        shopManager.reload();

        ShopCommand command = new ShopCommand(this, shopManager);
        getCommand("shop").setExecutor(command);
        getCommand("shop").setTabCompleter(command);

        getServer().getPluginManager().registerEvents(new ShopListener(this, shopManager), this);
        getLogger().info("MonayShop enabled for Paper 26.3.");
    }

    @Override
    public void onDisable() {
        Bukkit.getOnlinePlayers().forEach(player -> {
            if (player.getOpenInventory().getTopInventory().getHolder() instanceof MenuHolder) {
                player.closeInventory();
            }
        });
    }

    private boolean setupEconomy() {
        RegisteredServiceProvider<Economy> provider = getServer().getServicesManager().getRegistration(Economy.class);
        if (provider == null) {
            return false;
        }
        economy = provider.getProvider();
        return economy != null;
    }

    public Economy economy() {
        return economy;
    }
}
