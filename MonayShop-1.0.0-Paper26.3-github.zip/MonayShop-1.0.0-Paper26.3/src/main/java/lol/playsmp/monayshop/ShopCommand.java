package lol.playsmp.monayshop;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ShopCommand implements TabExecutor {
    private final MonayShop plugin;
    private final ShopManager manager;

    public ShopCommand(MonayShop plugin, ShopManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Text.color("&cThis command is in-game only."));
            return true;
        }
        if (!player.hasPermission("monayshop.use")) {
            player.sendMessage(Text.color(plugin.getConfig().getString("prefix", "") + plugin.getConfig().getString("messages.no-permission")));
            return true;
        }

        if (args.length == 0) {
            ShopMenus.openMain(plugin, manager, player);
            return true;
        }

        if (args[0].equalsIgnoreCase("reload")) {
            if (!player.hasPermission("monayshop.admin")) {
                player.sendMessage(Text.color(plugin.getConfig().getString("prefix", "") + plugin.getConfig().getString("messages.no-permission")));
                return true;
            }
            plugin.reloadConfig();
            manager.reload();
            player.sendMessage(Text.color(plugin.getConfig().getString("prefix", "") + plugin.getConfig().getString("messages.reloaded")));
            return true;
        }

        ShopCategory category = manager.category(args[0].toLowerCase(Locale.ROOT));
        if (category == null) {
            player.sendMessage(Text.color(plugin.getConfig().getString("prefix", "") + plugin.getConfig().getString("messages.invalid-category")));
            return true;
        }
        ShopMenus.openCategory(plugin, manager, player, category, 0);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1) return List.of();
        String prefix = args[0].toLowerCase(Locale.ROOT);
        List<String> values = new ArrayList<>(manager.categories().keySet());
        values.add("reload");
        return values.stream().filter(v -> v.startsWith(prefix)).sorted().toList();
    }
}
