package lol.playsmp.monayshop;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public final class ShopMenus {
    private static final int[] ITEM_SLOTS = {
            0, 1, 2, 3, 4, 5, 6, 7, 8,
            9, 10, 11, 12, 13, 14, 15, 16, 17,
            18, 19, 20
    };

    private ShopMenus() {}

    public static void openMain(MonayShop plugin, ShopManager manager, Player player) {
        int rows = Math.max(1, Math.min(6, plugin.getConfig().getInt("menu.rows", 3)));
        MenuHolder holder = new MenuHolder(MenuHolder.MenuType.MAIN, null, 0);
        Inventory inv = Bukkit.createInventory(holder, rows * 9,
                Text.color(plugin.getConfig().getString("menu.main-title", "&8ᴍᴏɴᴀʏsʜᴏᴘ")));
        holder.setInventory(inv);
        manager.decorate(inv, "&0");
        for (ShopCategory category : manager.categories().values()) {
            int slot = Math.max(0, Math.min(inv.getSize() - 1, category.slot()));
            inv.setItem(slot, manager.categoryIcon(category));
        }
        inv.setItem(22, infoItem(plugin, player));
        player.openInventory(inv);
    }

    public static void openCategory(MonayShop plugin, ShopManager manager, Player player, ShopCategory category, int page) {
        int maxPage = Math.max(0, category.pageCount() - 1);
        page = Math.max(0, Math.min(maxPage, page));
        MenuHolder holder = new MenuHolder(MenuHolder.MenuType.CATEGORY, category.id(), page);
        Component title = Text.color(plugin.getConfig().getString("menu.category-title", "&8ᴍᴏɴᴀʏsʜᴏᴘ &7• &f{category}")
                .replace("{category}", category.displayName()));
        Inventory inv = Bukkit.createInventory(holder, 27, title);
        holder.setInventory(inv);
        manager.decorate(inv, "&0");

        List<ShopItem> pageItems = manager.pageItems(category, page);
        for (int i = 0; i < pageItems.size() && i < ITEM_SLOTS.length; i++) {
            inv.setItem(ITEM_SLOTS[i], manager.shopItemIcon(pageItems.get(i)));
        }

        inv.setItem(plugin.getConfig().getInt("menu.back-slot", 18), button(
                Material.matchMaterial(plugin.getConfig().getString("menu.back-material", "RED_STAINED_GLASS_PANE")),
                "&cʙᴀᴄᴋ", List.of("&7Return to categories")));

        if (page < maxPage) {
            inv.setItem(plugin.getConfig().getInt("menu.next-slot", 26), button(
                    Material.matchMaterial(plugin.getConfig().getString("menu.next-material", "ARROW")),
                    "&aɴᴇxᴛ", List.of("&7Page " + (page + 2) + " / " + (maxPage + 1))));
        }

        if (page > 0) {
            inv.setItem(19, button(Material.ARROW, "&eᴘʀᴇᴠɪᴏᴜs", List.of("&7Page " + page + " / " + (maxPage + 1))));
        }

        inv.setItem(22, infoItem(plugin, player));
        player.openInventory(inv);
    }

    private static ItemStack button(Material material, String name, List<String> lore) {
        Material safe = material == null ? Material.ARROW : material;
        ItemStack item = new ItemStack(safe);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Text.color(name));
        meta.lore(lore.stream().map(Text::color).toList());
        item.setItemMeta(meta);
        return item;
    }

    private static ItemStack infoItem(MonayShop plugin, Player player) {
        ItemStack item = new ItemStack(Material.EMERALD);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Text.color("&#9CFF63ᴍᴏɴᴇʏ"));
        List<String> lore = new ArrayList<>();
        lore.add("&7Balance: &a$" + plugin.economy().format(plugin.economy().getBalance(player)));
        lore.add("");
        lore.add("&7Shop tips:");
        lore.add("&f• &aLeft &7= buy 1");
        lore.add("&f• &aShift-left &7= buy 16");
        lore.add("&f• &eRight &7= sell 1");
        lore.add("&f• &eShift-right &7= sell 16");
        lore.add("&f• &bMiddle &7= buy 64");
        meta.lore(lore.stream().map(Text::color).toList());
        item.setItemMeta(meta);
        return item;
    }
}
