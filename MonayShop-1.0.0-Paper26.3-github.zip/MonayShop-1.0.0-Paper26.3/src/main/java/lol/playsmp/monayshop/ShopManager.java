package lol.playsmp.monayshop;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ShopManager {
    private final MonayShop plugin;
    private final Map<String, ShopCategory> categories = new LinkedHashMap<>();
    private YamlConfiguration shops;

    public ShopManager(MonayShop plugin) {
        this.plugin = plugin;
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "shops.yml");
        shops = YamlConfiguration.loadConfiguration(file);
        categories.clear();

        ConfigurationSection root = shops.getConfigurationSection("categories");
        if (root == null) {
            plugin.getLogger().warning("No categories section found in shops.yml");
            return;
        }

        for (String id : root.getKeys(false)) {
            ConfigurationSection section = root.getConfigurationSection(id);
            if (section == null) continue;

            String display = section.getString("display", id);
            Material icon = material(section.getString("icon", "CHEST"), Material.CHEST);
            int slot = section.getInt("slot", 10);
            List<ShopItem> items = new ArrayList<>();

            ConfigurationSection itemSection = section.getConfigurationSection("items");
            if (itemSection != null) {
                for (String materialName : itemSection.getKeys(false)) {
                    Material mat = Material.matchMaterial(materialName);
                    if (mat == null || !mat.isItem()) {
                        plugin.getLogger().warning("Skipping invalid shop material: " + materialName + " in " + id);
                        continue;
                    }
                    double buy = itemSection.getDouble(materialName + ".buy", 0.0);
                    double sell = itemSection.getDouble(materialName + ".sell", 0.0);
                    items.add(new ShopItem(mat, Math.max(0, buy), Math.max(0, sell)));
                }
            }
            categories.put(id.toLowerCase(), new ShopCategory(id.toLowerCase(), display, icon, slot, List.copyOf(items)));
        }
    }

    private Material material(String name, Material fallback) {
        Material material = Material.matchMaterial(name == null ? "" : name);
        return material == null ? fallback : material;
    }

    public Map<String, ShopCategory> categories() {
        return Collections.unmodifiableMap(categories);
    }

    public ShopCategory category(String id) {
        return categories.get(id == null ? "" : id.toLowerCase());
    }

    public List<ShopItem> pageItems(ShopCategory category, int page) {
        int start = page * 21;
        if (start >= category.items().size()) return List.of();
        int end = Math.min(start + 21, category.items().size());
        return category.items().subList(start, end);
    }

    public ItemStack categoryIcon(ShopCategory category) {
        ItemStack item = new ItemStack(category.icon());
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Text.color("&#DE47EE" + category.displayName()));
        meta.lore(List.of(
                Text.color("&7Items: &f" + category.items().size()),
                Text.color("&7Click to browse")
        ));
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta);
        return item;
    }

    public ItemStack shopItemIcon(ShopItem shopItem) {
        ItemStack item = new ItemStack(shopItem.material());
        ItemMeta meta = item.getItemMeta();
        String name = prettify(shopItem.material());
        meta.displayName(Text.color("&#FFFFFF" + name));
        List<String> lore = new ArrayList<>();
        lore.add("");
        if (shopItem.canBuy()) {
            lore.add("&7Buy: &a$" + plugin.economy().format(shopItem.buyPrice()));
        } else {
            lore.add("&7Buy: &cDisabled");
        }
        if (shopItem.canSell()) {
            lore.add("&7Sell: &c$" + plugin.economy().format(shopItem.sellPrice()));
        } else {
            lore.add("&7Sell: &cDisabled");
        }
        lore.add("");
        lore.add("&aLeft-click &7• buy 1");
        lore.add("&aShift + left &7• buy 16");
        lore.add("&eRight-click &7• sell 1");
        lore.add("&eShift + right &7• sell 16");
        lore.add("&bMiddle-click &7• buy 64");
        meta.lore(lore.stream().map(Text::color).toList());
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta);
        return item;
    }

    public String prettify(Material material) {
        String[] words = material.name().toLowerCase().split("_");
        StringBuilder result = new StringBuilder();
        for (String word : words) {
            if (word.isEmpty()) continue;
            if (!result.isEmpty()) result.append(' ');
            result.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return result.toString();
    }

    public void decorate(Inventory inv, String color) {
        Material filler = material(plugin.getConfig().getString("menu.filler"), Material.BLACK_STAINED_GLASS_PANE);
        ItemStack pane = new ItemStack(filler);
        ItemMeta meta = pane.getItemMeta();
        meta.displayName(Text.color(color + ""));
        pane.setItemMeta(meta);
        for (int i = 0; i < inv.getSize(); i++) {
            if (inv.getItem(i) == null) inv.setItem(i, pane.clone());
        }
    }
}
