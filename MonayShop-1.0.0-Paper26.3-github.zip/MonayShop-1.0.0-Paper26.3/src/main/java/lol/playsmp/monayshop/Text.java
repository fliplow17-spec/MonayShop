package lol.playsmp.monayshop;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

public final class Text {
    private static final LegacyComponentSerializer AMP = LegacyComponentSerializer.builder()
            .character('&')
            .hexColors()
            .build();

    private Text() {}

    public static Component color(String value) {
        return AMP.deserialize(value == null ? "" : value);
    }

    public static String legacy(String value) {
        return value == null ? "" : AMP.serialize(color(value));
    }

    public static String replace(String text, String token, String value) {
        return text.replace(token, value);
    }
}
