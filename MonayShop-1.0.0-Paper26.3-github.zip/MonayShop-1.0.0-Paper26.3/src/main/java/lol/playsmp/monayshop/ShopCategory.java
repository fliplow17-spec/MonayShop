package lol.playsmp.monayshop;

import org.bukkit.Material;

import java.util.List;

public record ShopCategory(String id, String displayName, Material icon, int slot, List<ShopItem> items) {
    public int pageCount() {
        return Math.max(1, (items.size() + 20) / 21);
    }
}
