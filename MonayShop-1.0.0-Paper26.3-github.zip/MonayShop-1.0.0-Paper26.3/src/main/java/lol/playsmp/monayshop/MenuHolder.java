package lol.playsmp.monayshop;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public final class MenuHolder implements InventoryHolder {
    public enum MenuType { MAIN, CATEGORY }

    private final MenuType type;
    private final String categoryId;
    private final int page;
    private Inventory inventory;

    public MenuHolder(MenuType type, String categoryId, int page) {
        this.type = type;
        this.categoryId = categoryId;
        this.page = page;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public MenuType type() { return type; }
    public String categoryId() { return categoryId; }
    public int page() { return page; }
}
