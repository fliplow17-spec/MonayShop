package lol.playsmp.monayshop;

import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public final class ShopListener implements Listener {
    private final MonayShop plugin;
    private final ShopManager manager;

    public ShopListener(MonayShop plugin, ShopManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!(event.getView().getTopInventory().getHolder() instanceof MenuHolder holder)) return;

        event.setCancelled(true);
        if (event.getRawSlot() < 0 || event.getRawSlot() >= event.getView().getTopInventory().getSize()) return;

        if (holder.type() == MenuHolder.MenuType.MAIN) {
            handleMainClick(player, event.getRawSlot());
            return;
        }

        handleCategoryClick(player, holder, event.getRawSlot(), event.getClick());
    }

    private void handleMainClick(Player player, int slot) {
        for (ShopCategory category : manager.categories().values()) {
            if (category.slot() == slot) {
                ShopMenus.openCategory(plugin, manager, player, category, 0);
                return;
            }
        }
    }

    private void handleCategoryClick(Player player, MenuHolder holder, int slot, ClickType click) {
        ShopCategory category = manager.category(holder.categoryId());
        if (category == null) return;

        int backSlot = plugin.getConfig().getInt("menu.back-slot", 18);
        int nextSlot = plugin.getConfig().getInt("menu.next-slot", 26);
        if (slot == backSlot) {
            ShopMenus.openMain(plugin, manager, player);
            return;
        }

        int maxPage = Math.max(0, category.pageCount() - 1);
        if (slot == nextSlot && holder.page() < maxPage) {
            ShopMenus.openCategory(plugin, manager, player, category, holder.page() + 1);
            return;
        }

        if (slot == 19 && holder.page() > 0) {
            ShopMenus.openCategory(plugin, manager, player, category, holder.page() - 1);
            return;
        }

        List<ShopItem> pageItems = manager.pageItems(category, holder.page());
        int index = indexForSlot(slot);
        if (index < 0 || index >= pageItems.size()) return;

        ShopItem item = pageItems.get(index);
        int amount = amountFor(click);
        if (isSell(click)) {
            sell(player, item, amount);
        } else {
            buy(player, item, amount);
        }
    }

    private int indexForSlot(int slot) {
        int[] slots = {
                0, 1, 2, 3, 4, 5, 6, 7, 8,
                9, 10, 11, 12, 13, 14, 15, 16, 17,
                18, 19, 20
        };
        for (int i = 0; i < slots.length; i++) if (slots[i] == slot) return i;
        return -1;
    }

    private int amountFor(ClickType click) {
        if (click == ClickType.MIDDLE) return 64;
        if (click.isShiftClick()) return 16;
        return 1;
    }

    private boolean isSell(ClickType click) {
        return click == ClickType.RIGHT || click == ClickType.SHIFT_RIGHT;
    }

    private void buy(Player player, ShopItem item, int amount) {
        if (!item.canBuy()) {
            message(player, "invalid-item");
            return;
        }
        double price = item.buyPrice() * amount;
        if (!plugin.economy().has(player, price)) {
            String msg = plugin.getConfig().getString("messages.not-enough-money", "&cNot enough money.")
                    .replace("{needed}", plugin.economy().format(Math.max(0, price - plugin.economy().getBalance(player))));
            player.sendMessage(Text.color(prefix() + msg));
            return;
        }
        if (!canFit(player, item.material(), amount)) {
            message(player, "inventory-full");
            return;
        }

        EconomyResponse response = plugin.economy().withdrawPlayer(player, price);
        if (!response.transactionSuccess()) {
            message(player, "transaction-failed");
            return;
        }
        player.getInventory().addItem(new ItemStack(item.material(), amount));
        String msg = plugin.getConfig().getString("messages.buy-success", "&aBought.")
                .replace("{amount}", Integer.toString(amount))
                .replace("{item}", manager.prettify(item.material()))
                .replace("{price}", plugin.economy().format(price));
        player.sendMessage(Text.color(prefix() + msg));
    }

    private void sell(Player player, ShopItem item, int requested) {
        if (!item.canSell()) {
            message(player, "invalid-item");
            return;
        }
        int available = count(player, item.material());
        int amount = Math.min(requested, available);
        if (amount <= 0) {
            message(player, "not-enough-items");
            return;
        }

        double price = item.sellPrice() * amount;
        if (!removeItems(player, item.material(), amount)) {
            message(player, "transaction-failed");
            return;
        }

        EconomyResponse response = plugin.economy().depositPlayer(player, price);
        if (!response.transactionSuccess()) {
            player.getInventory().addItem(new ItemStack(item.material(), amount));
            message(player, "transaction-failed");
            return;
        }

        String msg = plugin.getConfig().getString("messages.sell-success", "&aSold.")
                .replace("{amount}", Integer.toString(amount))
                .replace("{item}", manager.prettify(item.material()))
                .replace("{price}", plugin.economy().format(price));
        player.sendMessage(Text.color(prefix() + msg));
    }

    private boolean canFit(Player player, Material material, int amount) {
        int remaining = amount;
        for (ItemStack stack : player.getInventory().getStorageContents()) {
            if (stack == null || stack.getType() == Material.AIR) {
                remaining -= material.getMaxStackSize();
            } else if (stack.isSimilar(new ItemStack(material))) {
                remaining -= Math.max(0, stack.getMaxStackSize() - stack.getAmount());
            }
            if (remaining <= 0) return true;
        }
        return remaining <= 0;
    }

    private int count(Player player, Material material) {
        int total = 0;
        for (ItemStack stack : player.getInventory().getStorageContents()) {
            if (stack != null && stack.getType() == material) total += stack.getAmount();
        }
        return total;
    }

    private boolean removeItems(Player player, Material material, int amount) {
        int remaining = amount;
        ItemStack[] storage = player.getInventory().getStorageContents();
        for (int i = 0; i < storage.length && remaining > 0; i++) {
            ItemStack stack = storage[i];
            if (stack == null || stack.getType() != material) continue;
            int remove = Math.min(remaining, stack.getAmount());
            stack.setAmount(stack.getAmount() - remove);
            remaining -= remove;
            storage[i] = stack.getAmount() == 0 ? null : stack;
        }
        player.getInventory().setStorageContents(storage);
        return remaining == 0;
    }

    private void message(Player player, String key) {
        player.sendMessage(Text.color(prefix() + plugin.getConfig().getString("messages." + key, "&cAction failed.")));
    }

    private String prefix() {
        return plugin.getConfig().getString("prefix", "");
    }
}
