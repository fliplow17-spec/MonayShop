# MonayShop

MonayShop is an original, configurable survival shop GUI for **Paper 26.3**. It uses the same kind of fast category → item browsing flow people expect from large competitive survival servers, without copying proprietary code, textures, or assets.

## Highlights

- `/shop` main category GUI
- Building Blocks, Farming, Redstone, Gear, Nether, and Utility categories
- Paginated 27-slot item shop
- Left-click: buy 1
- Shift-left: buy 16
- Right-click: sell 1
- Shift-right: sell 16
- Middle-click: buy 64
- Vault economy integration
- Fully configurable prices and GUI text
- Permission-based reload
- GitHub Actions build workflow
- No runtime dependencies bundled into the plugin JAR

## Requirements

- Paper 26.3
- Java 25
- Vault
- A Vault-compatible economy provider such as the economy plugin already used by your server

Paper 26.1+ requires Java 25. This project compiles against the Paper 26.3 API line. The plugin descriptor intentionally uses API `26.2` for compatibility with Paper's documented plugin-api range while remaining suitable for a 26.3 server.

## Build

### GitHub

Push this folder to a repository. The included workflow builds the plugin automatically on pushes, pull requests, and manual workflow runs. Download the resulting JAR from the workflow artifact.

### Local

Install JDK 25 and Gradle 9.1 or newer, then run:

```bash
gradle build
```

The JAR will be written to `build/libs/MonayShop-1.0.0.jar`.

## Install

1. Put the built `MonayShop-1.0.0.jar` into your server's `plugins/` folder.
2. Make sure Vault and your economy provider are installed.
3. Restart the server.
4. Run `/shop` in-game.
5. Edit `plugins/MonayShop/shops.yml` to change prices.
6. Run `/shop reload` with `monayshop.admin` permission after changes.

## Commands

```text
/shop
/shop <category>
/shop reload
```

## Permissions

```text
monayshop.use   - Use the shop (default: true)
monayshop.admin - Reload the shop configuration (default: op)
```

## Pricing format

```yaml
DIAMOND: { buy: 250.0, sell: 62.5 }
```

Set `buy: 0` or `sell: 0` to disable one side of a transaction.

## MonaySMP-specific restrictions

The default shop intentionally does not include explosive-PvP materials such as obsidian, end crystals, respawn anchors, or TNT. Add them only if your server's gameplay rules change.

## Customization

Edit:

- `src/main/resources/config.yml` for titles, colors, buttons, and messages
- `src/main/resources/shops.yml` for categories, slots, item lists, and prices

The implementation uses normal Paper/Bukkit inventory APIs plus Vault. No NMS, packet hacks, or client mods are required.

## License

MIT. See `LICENSE`.
